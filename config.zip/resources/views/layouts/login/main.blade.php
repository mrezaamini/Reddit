@include('layouts.login.header')
@yield('content')
@include('layouts.login.footer')