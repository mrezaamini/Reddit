<script>
    less={
        env: 'development'
    }
</script>
<script src="{{asset('assets/construct/less.min.js')}}"></script>
<script src="{{asset('assets/construct/jquery.min.js')}}"></script>
@yield('script')
<script src="{{asset('assets/construct/input/input.js')}}"></script>
<script src="{{asset('assets/construct/notice/notice.js')}}"></script>
<script src="{{asset('assets/construct/balloon/balloon.js')}}"></script>
<script src="{{asset('assets/construct/panel/script.js')}}"></script>
</body>
</html>
