<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/account/user/index.blade.php ENDPATH**/ ?>