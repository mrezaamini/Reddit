<?php $__env->startSection('content'); ?>
    <div class="block">
        <div class="header">
            <div class="title">
                <h6> انجمن های ایجاد شده </h6>
                <p> در این قسمت می توانید انجمن های ایجاد شده را مدیریت کنید </p>
            </div>
            <div class="tool-bar">
                <ul>
                    <li><a href="/account/user/forum/add"> ایجاد انجمن جدید <i class="far fa-angle-left"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="body">
            <div class="table-mask">
                <table>
                    <thead>
                    <tr>
                        <th> ردیف </th>
                        <th> عنوان </th>
                        <th> دسته بندی ها </th>
                        <th> نفرات عضو شده </th>
                        <th> پست ها </th>
                        <th> تاریخ ثبت </th>
                        <th> آخرین ویرایش </th>
                        <th> گزینه ها </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($forum->title); ?></td>
                            <td><span class="label label-primary bg-reverse"><?php echo e(count(json_decode($forum->category))); ?></span></td>
                            <td><span class="label label-success bg-reverse">0</span></td>
                            <td><span class="label label-warning bg-reverse">0</span></td>
                            <td><span class="label label-default"><?php echo e(verta($forum->created_at)->format('d %B Y')); ?></span></td>
                            <td><span class="label label-default"><?php echo e(verta($forum->updated_at)->format('d %B Y')); ?></span></td>
                            <td>
                                <ul class="menu">
                                    <li class="balloon" balloon-position="right" balloon-text="ویرایش"><a href="/account/user/forum/<?php echo e($forum->id); ?>/edit"><i class="far fa-cog"></i></a></li>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/account/user/forum/index.blade.php ENDPATH**/ ?>