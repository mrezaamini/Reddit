<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> انجمن </title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/construct/bootstrap-12-grid.css?version='.env('APP_VERSION'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/construct/font/fontiran.css?version='.env('APP_VERSION'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/construct/fontawesome/css/all.min.css?version='.env('APP_VERSION'))); ?>">
    <link rel="stylesheet/less" type="text/css" href="<?php echo e(asset('assets/home/app.less?version='.env('APP_VERSION'))); ?>">
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>


<header>
    <div class="container">
        <div class="menu">
            <ul>
                <li><a href="#"> انجمن </a></li>
            </ul>
            <form method="post">
                <?php echo csrf_field(); ?>
                <input type="text" name="keyword" autocomplete="off">
                <button><i class="fal fa-search"></i></button>
            </form>
        </div>
        <div class="account">
            <?php if(auth('user')->check()): ?>
                <a href="/account/user/logout"> خروج </a>
                <a href="/account/user/desk"> حساب کاربری </a>
            <?php else: ?>
                <a href="/account/register"> ثبت نام کنید </a>
                <a href="/account/login"> وارد شوید </a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/layouts/home/header.blade.php ENDPATH**/ ?>