<script>
    less={
        env: 'development'
    }
</script>
<script src="<?php echo e(asset('assets/construct/less.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/construct/jquery.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<script src="<?php echo e(asset('assets/construct/input/input.js')); ?>"></script>
<script src="<?php echo e(asset('assets/construct/notice/notice.js')); ?>"></script>
<script src="<?php echo e(asset('assets/construct/balloon/balloon.js')); ?>"></script>
<script src="<?php echo e(asset('assets/home/script.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/layouts/home/footer.blade.php ENDPATH**/ ?>