<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> حساب کاربری (پنل مدیریت) </title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/construct/bootstrap-18-grid.css?version='.env('APP_VERSION'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/construct/font/fontiran.css?version='.env('APP_VERSION'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/construct/fontawesome/css/all.min.css?version='.env('APP_VERSION'))); ?>">
    <link rel="stylesheet/less" type="text/css" href="<?php echo e(asset('assets/construct/panel/app.less?version='.env('APP_VERSION'))); ?>">
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>


<header>
    <div class="tool-bar">
        <a href="/account/user/logout" class="logout">
            <i class="far fa-arrow-right-from-bracket"></i>
            <span> خروج </span>
        </a>
    </div>
    <div class="welcome">
        <p> به حساب <span> کاربری </span> خوش آمدید! </p>
    </div>
</header>
<?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/layouts/account/user/header.blade.php ENDPATH**/ ?>