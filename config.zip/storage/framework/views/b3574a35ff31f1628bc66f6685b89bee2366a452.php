<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="header">
                <div class="title">
                    <h6><?php echo e($forum->title); ?></h6>
                </div>
                <div class="join">
                    <?php if(auth('user')->check()): ?>
                        <?php if(auth('user')->user()->forums()->where('id','=',$forum->id)->exists()): ?>
                            <span> شما سازنده انجمن هستید </span>
                        <?php else: ?>
                            <?php if(false): ?>
                                <span> شما عضو این انجمن هستید </span>
                            <?php else: ?>
                                <a href="/<?php echo e($forum->slug); ?>/join"> عضویت در انجمن </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <span> برای عضویت در ابتدا وارد حساب کاربری شوید </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="body">
                <div class="demo">
                    <p><?php echo e($forum->demo); ?></p>
                </div>
            </div>
            <div class="footer">
                <div class="profile">
                    <div class="avatar">
                        <img src="<?php echo e($forum->user->avatar ? Storage::disk('public_media')->url($forum->user->avatar) : asset('assets/construct/media/avatar.svg')); ?>">
                    </div>
                    <div class="name">
                        <p><?php echo e($forum->user->name.' '.$forum->user->surname); ?></p>
                    </div>
                </div>
                <div class="information">
                    <ul>
                        <li class="primary">
                            <span> ۱۱۶ عضو </span>
                        </li>
                        <li class="success">
                            <span> ۲۶ پست </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/home/forum/show.blade.php ENDPATH**/ ?>