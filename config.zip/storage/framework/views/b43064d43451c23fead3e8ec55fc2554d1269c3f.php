<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4">
                    <div class="card">
                        <div class="header">
                            <div class="title">
                                <h6><?php echo e($forum->title); ?></h6>
                            </div>
                        </div>
                        <div class="body">
                            <div class="demo">
                                <p><?php echo e(Str::limit(strip_tags($forum->demo),250)); ?></p>
                            </div>
                        </div>
                        <div class="footer">
                            <a href="/<?php echo e($forum->slug); ?>/information"> ورود به انجمن </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nima Asaadi\Documents\Project\Reddit\resources\views/home/forum/index.blade.php ENDPATH**/ ?>