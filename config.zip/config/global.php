<?php
return [
    'permissions'=>[

        // User
        'user'=>[

        ],

    ],
];
